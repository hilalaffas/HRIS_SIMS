import React, { useState } from 'react';
import './FormKaryawan.css';
import { registerKaryawan } from '../../../services/karyawanService';

// Peta Hak Akses (Role) -> Jabatan (Posisi) yang boleh dipilih.
// SUPER_ADMIN sengaja tidak dimasukkan karena untuk sementara dinonaktifkan.
const ROLE_POSITION_MAP = {
  Member: ['Staff'],
  MANAGER: ['Leader', 'SPV', 'Manager'],
  HRD_Admin: ['HRD_Admin', 'HRD_Karyawan'],
};

// Peta Jabatan (Posisi) -> roleId yang dikirim ke backend.
// Sumber kebenaran roleId ada di Jabatan (lebih spesifik), bukan di Hak Akses (yang cuma grup besar).
const POSITION_ROLE_ID_MAP = {
  HRD_Admin: 2,
  HRD_Karyawan: 3,
  Manager: 4,
  SPV: 5,
  Leader: 6,
  Staff: 7,
};

// Nilai awal form. Kalau field ini tidak boleh mengatur Hak Akses, langsung dikunci
// ke Member/Staff supaya konsisten dengan pembatasan Jabatan di atas.
const getInitialFormData = (canManageRole) => ({
  fullName: '', nik: '', joinDate: '', division: '',
  position: canManageRole ? '' : 'Staff',
  address: '', email: '', phone: '',
  emergencyContact: '', emergencyRelation: '', emergencyPhone: '',
  username: '', password: '',
  role: canManageRole ? '' : 'Member',
  gender: '',
});

const FormKaryawan = ({ onSubmit, canManageRole }) => {
const [fileName, setFileName] = useState("Tidak ada file");
const [file, setFile] = useState(null);

const handleFileChange = (e) => {
    if (e.target.files.length > 0) {
      setFileName(e.target.files[0].name);
      setFile(e.target.files[0]); // Simpan file asli ke state
    }
  };
  const [formData, setFormData] = useState(() => getInitialFormData(canManageRole));
  const [showPassword, setShowPassword] = useState(false);
  // Berubah setiap submit sukses, dipakai sebagai key <form> supaya semua input
  // (termasuk yang uncontrolled seperti Nama, Email, dst) ikut ter-reset ke kosong.
  const [formResetKey, setFormResetKey] = useState(0);

  // Jabatan yang boleh dipilih untuk Hak Akses yang sedang aktif.
  // undefined kalau Hak Akses belum dipilih (Jabatan akan di-disable).
  const allowedPositions = ROLE_POSITION_MAP[formData.role];

const handleInputChange = (e) => {
  const { name, value } = e.target;
  let updatedFormData = { ...formData, [name]: value };

  // Hak Akses (Role) menentukan Jabatan mana yang boleh dipilih.
  if (name === 'role') {
    const allowed = ROLE_POSITION_MAP[value] || [];
    if (allowed.length === 1) {
      // Kalau cuma ada 1 pilihan Jabatan, isi otomatis (mis. Member -> Staff)
      updatedFormData.position = allowed[0];
    } else if (!allowed.includes(updatedFormData.position)) {
      // Reset Jabatan kalau tidak cocok lagi dengan Hak Akses baru
      updatedFormData.position = '';
    }
  }

  setFormData(updatedFormData);
};

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();
    // roleId diambil dari Jabatan (lebih spesifik), sesuai POSITION_ROLE_ID_MAP di atas.
    // Default aman kalau belum terisi: Member/Staff (7), bukan SUPER_ADMIN.
    const mappedRoleId = POSITION_ROLE_ID_MAP[formData.position] || 7;

    // Disesuaikan dengan pilihan yang benar-benar ada di dropdown HUBUNGAN KONTAK DARURAT
    const relMap = { 'Orang Tua': 1, 'Pasangan': 2, 'Saudara Kandung': 3, 'Teman Dekat': 4 };
    const mappedRelId = relMap[formData.emergencyRelation] || 1;

    // Mapping field agar SAMA PERSIS dengan Backend RegisterRequest.java
    data.append('username', formData.username);
    data.append('password', formData.password);
    data.append('email', formData.email);
    data.append('fullName', formData.fullName);
    data.append('address', formData.address);
    data.append('phoneNumber', formData.phone); // Frontend: phone -> Backend: phoneNumber
    data.append('nikKaryawan', formData.nik);   // Frontend: nik -> Backend: nikKaryawan
    // Pastikan kirim sebagai angka (Integer/Long)
    data.append('roleId', mappedRoleId);
    data.append('emergencyContactPhone', formData.emergencyPhone);
    data.append('emergencyContactName', formData.emergencyContact);
    data.append('emergencyContactRelationshipId', mappedRelId);
    data.append('gender', formData.gender);
    

    // Append File
    if (file) {
      data.append('photo', file);
    }

    try {
        // Panggil endpoint register dari karyawanService.js
        await registerKaryawan(data);
        alert('Data Karyawan berhasil disimpan!');
        
        // Kembalikan objek data form (tanpa mapping integer) ke UI tabel jika diperlukan
        if (onSubmit) onSubmit(formData);

        // Reset form supaya siap dipakai menambah karyawan berikutnya tanpa refresh halaman
        setFormData(getInitialFormData(canManageRole));
        setFile(null);
        setFileName('Tidak ada file');
        setShowPassword(false);
        setFormResetKey((prev) => prev + 1); // remount <form> agar input uncontrolled ikut kosong
    } catch (error) {
        alert('Gagal menyimpan: ' + error.message);
    }
  };

  return (
    <div className="form-card_formkaryawan">
      {/* HEADER FORM DENGAN WARNA SOFT HIJAU */}
      <div className="form-header-soft_formkaryawan">
        <div className="icon-user-add_formkaryawan">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M15 8C15 10.21 13.21 12 11 12C8.79 12 7 10.21 7 8C7 5.79 8.79 4 11 4C13.21 4 15 5.79 15 8ZM11 14C6.67 14 2 16.14 2 19V20H20V19C20 16.14 15.33 14 11 14ZM20 12V9H18V12H15V14H18V17H20V14H23V12H20Z" fill="currentColor"/>
          </svg>
        </div>
        Tambah Karyawan
      </div>
      
      <form key={formResetKey} onSubmit={handleSubmit} className="form-body_formkaryawan">
        {/* Kolom Kiri */}
        <div className="form-column">
          <h3 className="section-title_formkaryawan">DATA PERSONAL & DIVISI</h3>
          
          <div className="input-group_formkaryawan">
            <label>FOTO PROFIL</label>
            <div className="file-upload-container">
              <label htmlFor="arquivo" className="btn-upload_formkaryawan">
                Choose File
              </label>
              <span className="file-name_formkaryawan">{fileName}</span>
              <input 
                type="file" 
                id="arquivo" 
                className="file-input-hidden" 
                onChange={handleFileChange} 
                accept=".jpg, .jpeg, .png, .gif, .pdf" 
              />
            </div>
          </div>
          
          <div className="input-group_formkaryawan">
            <label>NAMA LENGKAP *</label>
            <input type="text" name="fullName" onChange={handleInputChange} required />
          </div>

          <div className="input-group_formkaryawan">
            <label>JENIS KELAMIN *</label>
            <select 
              name="gender" 
              value={formData.gender} 
              onChange={handleInputChange} 
              required
            >
              <option value="">Pilih Jenis Kelamin...</option>
              <option value="L">Laki-laki</option>
              <option value="P">Perempuan</option>
            </select>
          </div>
          
          <div className="grid-2-col_formkaryawan">
            <div className="input-group_formkaryawan">
              <label>NIK KARYAWAN *</label>
              <input type="text" name="nik" onChange={handleInputChange} required />
            </div>
            <div className="input-group_formkaryawan">
              <label>TGL MASUK</label>
              <input type="date" name="joinDate" onChange={handleInputChange} />
            </div>
          </div>

          <div className="grid-2-col_formkaryawan">
            <div className="input-group_formkaryawan">
              <label>DIVISI / DEPT *</label>
              <select name="division" onChange={handleInputChange} required>
                <option value="">Pilih Divisi / Dept...</option>
                <option value="Tantai Kensa (Aisin)">Tantai Kensa (Aisin)</option>
                <option value="Kaihatsu">Kaihatsu</option>
                <option value="TTSI">TTSI</option>
                <option value="Others">Others</option>
              </select>
            </div>
            <div className="input-group_formkaryawan">
              <label>JABATAN</label>
              {/* --- SELECT JABATAN: dibatasi oleh Hak Akses (Role) yang dipilih --- */}
              <select 
                name="position" 
                value={formData.position} 
                onChange={handleInputChange}
                disabled={!formData.role}
              >
                <option value="">
                  {formData.role ? 'Pilih Jabatan...' : 'Pilih Hak Akses dahulu'}
                </option>
                <option value="Staff" disabled={!allowedPositions?.includes('Staff')}>Staff</option>
                <option value="Leader" disabled={!allowedPositions?.includes('Leader')}>Leader</option>
                <option value="SPV" disabled={!allowedPositions?.includes('SPV')}>SPV</option>
                <option value="Manager" disabled={!allowedPositions?.includes('Manager')}>Manager</option>
                <option value="HRD_Admin" disabled={!allowedPositions?.includes('HRD_Admin')}>HR Admin</option>
                <option value="HRD_Karyawan" disabled={!allowedPositions?.includes('HRD_Karyawan')}>HR Karyawan</option>
              </select>
              {!formData.role && (
                <span className="hint-text_formkaryawan">Pilih Hak Akses Sistem dahulu di kolom kanan</span>
              )}
            </div>
          </div>

          <div className="input-group_formkaryawan">
            <label>ALAMAT DOMISILI</label>
            <textarea name="address" rows="3" onChange={handleInputChange}></textarea>
          </div>
        </div>

        {/* Kolom Kanan */}
        <div className="form-column">
          <h3 className="section-title_formkaryawan">KREDENSIAL & KONTAK</h3>
          


          <div className="grid-2-col_formkaryawan">
            <div className="input-group_formkaryawan">
              <label>EMAIL PERUSAHAAN</label>
              <input type="email" name="email" onChange={handleInputChange} />
            </div>
            <div className="input-group_formkaryawan">
              <label>NO. HANDPHONE</label>
              <input type="text" name="phone" onChange={handleInputChange} />
            </div>  
          </div>
          <div className="grid-2-col_formkaryawan">
          <div className="input-group_formkaryawan error-state">
                <label className="text-red_formkaryawan">KONTAK DARURAT (NAMA)</label>
                <input type="text" name="emergencyContact" onChange={handleInputChange}           className="border-red_formkaryawan" />
              </div>
              <div className="input-group_formkaryawan error-state">
                <label className="text-red_formkaryawan">NO. HP DARURAT</label>
                <input type="text" name="emergencyPhone" onChange={handleInputChange}           className="border-red_formkaryawan" />
              </div>
          </div>

          <div className="input-group_formkaryawan error-state">
            <label className="text-red_formkaryawan">HUBUNGAN KONTAK DARURAT</label>
            <select name="emergencyRelation" onChange={handleInputChange} className="border-red_formkaryawan">
              <option value="">Pilih Hubungan...</option>
              <option value="Orang Tua">Orang Tua</option>
              <option value="Pasangan">Pasangan</option>
              <option value="Saudara Kandung">Saudara Kandung</option>
              <option value="Teman Dekat">Teman Dekat</option>
            </select>
          </div>

          <div className="credential-box_formkaryawan">
            <div className="grid-2-col_formkaryawan">
              <div className="input-group_formkaryawan">
                <label>USERNAME LOGIN *</label>
                <input type="text" name="username" onChange={handleInputChange} required />
              </div>
              <div className="input-group_formkaryawan">
                <label>PASSWORD *</label>
                <div className="password-wrapper_formkaryawan">
                  <input type={showPassword ? "text" : "password"} name="password" onChange={handleInputChange} required />
                  <span className="eye-icon_formkaryawan" onClick={() => setShowPassword(!showPassword)}>👁️</span>
                </div>
              </div>
            </div>
            {canManageRole && (
              <div className="input-group_formkaryawan mt-3">
                <label>HAK AKSES SISTEM (ROLE) *</label>
                {/* --- SELECT HAK AKSES (ROLE) --- */}
                <select 
                  name="role" 
                  value={formData.role} 
                  onChange={handleInputChange} 
                  required
                >
                  <option value="">Pilih Akses...</option>
                  <option value="Member">Karyawan Biasa (Member)</option>
                  <option value="MANAGER">Manager / Supervisor / Leader</option>
                  <option value="HRD_Admin">Admin (HR)</option>
                  <option value="SUPER_ADMIN" disabled>Superadmin (Nonaktif Sementara)</option>
                </select>
              </div>
            )}
          </div>
        </div>
        <div className="form-actions_formkaryawan">
          <button type="submit" className="btn-submit_formkaryawan">✓ Tambahkan Karyawan</button>
        </div>
      </form>
    </div>
  );
};

export default FormKaryawan;